#!/usr/bin/env bash
set -euo pipefail

# Usage: ./deploy_to_github.sh <your-github-username> <new-repo-name> [email]
# Example: ./deploy_to_github.sh pavan9687 campus-event-management "pavan@example.com"

if [[ $# -lt 2 ]]; then
  echo "Usage: $0 <github-username> <repo-name> [email]"
  exit 1
fi

USER_NAME="$1"
REPO_NAME="$2"
USER_EMAIL="${3:-${USER_NAME}@users.noreply.github.com}"

# Ensure we're in the script directory
cd "$(dirname "$0")"

# Initialize git
git init

# Set author identity for this repo only
git config user.name "pavan"
git config user.email "$USER_EMAIL"

# Make initial commit
git add .
git commit -m "Initial commit: Campus Event Management Platform"

# Create GitHub repo via gh CLI if available
if command -v gh >/dev/null 2>&1; then
  gh repo create "$USER_NAME/$REPO_NAME" --public --source=. --remote=origin --push
else
  # Fall back to manual remote creation
  echo "gh CLI not found. Create the repo at: https://github.com/new (name: $REPO_NAME)"
  echo "Then run:"
  echo "  git branch -M main"
  echo "  git remote add origin git@github.com:$USER_NAME/$REPO_NAME.git   # or https://github.com/$USER_NAME/$REPO_NAME.git"
  echo "  git push -u origin main"
fi

echo "Done. Repository ready."
